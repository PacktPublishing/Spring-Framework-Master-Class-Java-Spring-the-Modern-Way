package com.in28minutes.spring.basics.springin5steps.basic;

public interface SortAlgorithm {
	int[] sort(int[] numbers);
}
